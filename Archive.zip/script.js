const largestRegionsByArea = [
    {
      region: 'Красноярский край',
      population: '2,828,187',
      area: '2,339,700 км²',
      historicalFact: 'Красноярский край славится своими заповедниками и природными достопримечательностями, такими как Ергаки и Столбы.'
    },
    {
      region: 'Саха (Якутия) Республика',
      population: '964,330',
      area: '3,083,523 км²',
      historicalFact: 'Республика Саха (Якутия) – крупнейшая регион по площади в России, известна своими уникальными природными явлениями и культурой коренных народов.'
    },
    {
      region: 'Таймырский (Долгано-Ненецкий) автономный округ',
      population: '39,786',
      area: '862,100 км²',
      historicalFact: 'Таймырский автономный округ – один из самых северных регионов, богатый природными ресурсами, а также место проживания малочисленных народов Севера.'
    },
    {
      region: 'Республика Коми',
      population: '840,873',
      area: '415,900 км²',
      historicalFact: 'Республика Коми известна своими лесными массивами, уникальными пейзажами и традиционной культурой коренных народов.'
    },
    {
      region: 'Иркутская область',
      population: '2,402,138',
      area: '767,900 км²',
      historicalFact: 'Иркутская область богата природными ресурсами, включая озеро Байкал, и имеет богатую историю культурного развития.'
    },
    {
      region: 'Ханты-Мансийский автономный округ - Югра',
      population: '1,601,167',
      area: '523,100 км²',
      historicalFact: 'Ханты-Мансийский автономный округ славится своими запасами природных ресурсов, включая нефть и газ, и богатой культурой местных народов.'
    },
    {
      region: 'Ямало-Ненецкий автономный округ',
      population: '541,479',
      area: '750,300 км²',
      historicalFact: 'Ямало-Ненецкий автономный округ – центр добычи природного газа и место проживания коренных народов Севера, таких как ненцы и ханты.'
    },
    {
      region: 'Краснодарский край',
      population: '5,707,223',
      area: '76,000 км²',
      historicalFact: 'Краснодарский край известен своими курортами на Черном море и богатством культурного наследия.'
    },
    {
      region: 'Тюменская область',
      population: '3,655,259',
      area: '1,435,200 км²',
      historicalFact: 'Тюменская область – важный центр добычи нефти и газа, а также обладатель обширных природных ресурсов.'
    },
    {
      region: 'Омская область',
      population: '1,869,860',
      area: '139,700 км²',
      historicalFact: 'Омская область располагается на западе Сибири и известна своими культурными достопримечательностями и историей.'
    }
  ];

const popupTemplate = document.querySelector('#popup__template').content.querySelector('.popup'); 
const popupContainer = document.querySelector('.place__popup'); 
const popupButtons = document.querySelectorAll('.open-popup');

function createPopup(popupData, onDelete, num) {
    const popupElement = popupTemplate.cloneNode(true); 
    const deleteButton = popupElement.querySelector('.close-popup');

    popupElement.querySelector('.card-title').textContent = popupData[num].region;
    popupElement.querySelector('.population').textContent = `Население: ${popupData[num].population}`;
    popupElement.querySelector('.area').textContent = `Площадь (м2): ${popupData[num].area}`;
    popupElement.querySelector('.historical_fact').textContent = `Интересный факт: ${popupData[num].historicalFact}`;

    deleteButton.addEventListener('click', () => onDelete(popupElement));

    return popupElement;
}

function deleteCard(card) {
    card.remove();
}

popupButtons.forEach(button => {
  button.addEventListener('click', function(event){
    const key = event.currentTarget.getAttribute('data-key');
    popupContainer.appendChild(createPopup(largestRegionsByArea, deleteCard, key));
    document.querySelector('.popup').classList.add('active');
  })
});
  

